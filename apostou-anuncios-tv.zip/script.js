
const ads = [
    { type: "video", src: "anuncios/demo.mp4", duration: 15000 },
    { type: "image", src: "anuncios/demo.jpg", duration: 8000 }
];

let currentIndex = 0;
const videoPlayer = document.getElementById("videoPlayer");
const imagePlayer = document.getElementById("imagePlayer");

function showNextAd() {
    const ad = ads[currentIndex];
    if (ad.type === "video") {
        imagePlayer.style.display = "none";
        videoPlayer.src = ad.src;
        videoPlayer.style.display = "block";
        videoPlayer.play();
    } else {
        videoPlayer.pause();
        videoPlayer.style.display = "none";
        imagePlayer.src = ad.src;
        imagePlayer.style.display = "block";
    }

    setTimeout(() => {
        currentIndex = (currentIndex + 1) % ads.length;
        showNextAd();
    }, ad.duration);
}

showNextAd();

// Atualizar hora e data
function atualizarRelogio() {
    const agora = new Date();
    const horas = agora.getHours().toString().padStart(2, '0');
    const minutos = agora.getMinutes().toString().padStart(2, '0');
    const segundos = agora.getSeconds().toString().padStart(2, '0');
    const dia = agora.getDate().toString().padStart(2, '0');
    const mes = (agora.getMonth() + 1).toString().padStart(2, '0');
    const ano = agora.getFullYear();

    document.getElementById("relogio").textContent = `${horas}:${minutos}:${segundos}`;
    document.getElementById("data").textContent = `${dia}/${mes}/${ano}`;
}
setInterval(atualizarRelogio, 1000);
atualizarRelogio();
